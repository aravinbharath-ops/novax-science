window.NOVAX_CONTENT = {
  brand: {
    logo: "assets/logo.svg"
  },

  hero: {
    eyebrow: "NOVAX SCIENCE · RESEARCH MATERIALS",
    titleLine1: "Verify the vial.",
    titleLine2: "Trust the batch.",
    description: "A focused catalogue of research-use-only peptide formats supported by clear product identification, batch-level verification and responsible labelling.",
    image: "assets/retatrutide-10mg-packaging.jpg"
  },

  productsHeading: {
    eyebrow: "COMPLETE CATALOGUE",
    title: "Fourteen focused research formats.",
    description: "Browse the current Novax Science product range. Select any format to continue to batch verification."
  },

  products: [
    { name: "Retatrutide", amount: "10 mg", code: "R10", image: "assets/retatrutide-10mg-packaging.jpg", featured: true },
    { name: "Retatrutide", amount: "30 mg", code: "R30", image: "" },
    { name: "GHK-Cu", amount: "100 mg", code: "GHK", image: "" },
    { name: "NAD+", amount: "500 mg", code: "NAD", image: "" },
    { name: "Semaglutide", amount: "10 mg", code: "S10", image: "" },
    { name: "Tirzepatide", amount: "15 mg", code: "T15", image: "" },
    { name: "AOD-9604", amount: "5 mg", code: "AOD", image: "" },
    { name: "Tesamorelin", amount: "10 mg", code: "TES", image: "" },
    { name: "PT-141", amount: "10 mg", code: "PT", image: "" },
    { name: "BPC-157 + TB-500", amount: "10 mg", code: "BT", image: "" },
    { name: "KLOW", amount: "80 mg", code: "KL", image: "" },
    { name: "GLOW", amount: "70 mg", code: "GL", image: "" },
    { name: "CJC + Ipamorelin", amount: "10 mg", code: "CI", image: "" },
    { name: "AHK-Cu", amount: "100 mg", code: "AHK", image: "" }
  ]
};